# About JavaScript IDP

## JavaScript IDP Guidelines

**Agenda:**

- About the JavaScript IDP Test

**Purpose:**

- JavaScript IDP helps you assess your Industry Readiness and improve your skills further.

**Exam Pattern:**

- It consists of 4 rounds
    - **Round 1:**
        - MCQ Round: Consists of 25 Questions
        - Syllabus: JavaScript
        - Duration: 20 mins
        - Scoring Pattern: +2 for Correct Answer, -1 for Wrong Answer.
        - Upon clearing this round, you will qualify to write round 2.
        - Qualifying Score for next round: 45 score out of 50.
        
    - **Round 2:**
        - MCQ Round: Consists of  25 Questions
        - Syllabus: JavaScript
        - Duration: 25 mins
        - Scoring Pattern: +2 for Correct Answer, -1 for Wrong Answer.
        - Upon clearing this round, you will qualify to write round 3.
        - Qualifying Score for next round: 45 score out of 50.
    
    - **Round 3:**
        - Coding Test Round: Consists of 4 Questions
        - Syllabus: JavaScript
        - Duration: 2 hours, 30 mins
        - Upon clearing this round, you will qualify to write round 4.
        - Qualifying score for the next round: 90%
    
    - **Round 4:**
        - Web Coding Test Round: Consists of 1 Question
        - Syllabus: HTML, CSS, Bootstrap, JavaScript
        - Duration: 3 hours

### **Note:** Even though all the rounds of the JavaScript IDP test are unlocked, You must attempt all four rounds from the beginning on every new attempt of JavaScript IDP. Scores will be considered only if you attempt from Round 1.